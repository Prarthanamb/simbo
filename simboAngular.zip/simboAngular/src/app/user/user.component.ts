import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  toppings = new FormControl();
  toppingList: string[] = ['admin', 'user', 'staff','zoneadmin'];
  constructor( private http: HttpClient) { }
id: string;
role:any;
userReq:any={};
userRes:any={};
userurl:any={};
  ngOnInit() {
  }

   updateUser(){

    this.userReq.id = this.id;
    this.userReq.role = this.role;
    this.userurl = 'http://192.168.0.51:10010/user';
    console.log("this.userReq->" + JSON.stringify(this.userReq));
    console.log("this.userurl->" + this.userurl);
    this.http.post(this.userurl, this.userReq)
      .subscribe(x => {
        this.userRes = x;
        // console.log(" this.userRes->" + JSON.stringify(this.userRes));
        if (this.userRes.status == 'success') {
console.log("user Successful");

        }
        else {

        }
      }, () => {
      });


     console.log("id->"+ this.id);
     console.log("role->"+ this.role);
    console.log("Inside Update User");
  }
}
