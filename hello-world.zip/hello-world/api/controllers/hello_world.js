'use strict';
var moment = require('moment');
var util = require('util');

const cassandra = require('cassandra-driver');

const client = new cassandra.Client({
  contactPoints: ['127.0.0.1'],
  keyspace: 'simbo'
});

client.connect(function (err, result) {
  if (err) {
    console.log('cassandra not connected', err);
  } else {
    console.log("Cassandra Connected")
  }
});

module.exports = {
  validateUser,
  getUsers,
  user
};

function validateUser(req, res) {
  var id = req.body.id;
  var pwd = req.body.pwd;

  var validateUserQ = " select pwd,role from user where id='" + id + "'";
  // console.log("query->" + validateUserQ);
  client.execute(validateUserQ, function (err, result) {
    if (err) {
      console.log("Eror rin code->" + err);
    }
    else {
      console.log('User with email %s', result.rows[0].pwd);
      if (result.rows[0].pwd == pwd) {
        console.log("result.rows[0].role->"+result.rows[0].role);
        // var checkForAdmin=result.rows[0].role.indexOf('admin');
        var checkForAdmin=0;
var roleArr=result.rows[0].role.split(",");
console.log("roleArr->"+ JSON.stringify(roleArr));
for(var i=0;i<roleArr.length;i++){
  if(roleArr[i]=='admin'){
    checkForAdmin=1;
  }
}

        console.log("checkForAdmin->"+checkForAdmin);
        if(checkForAdmin==1){
          var resObj = {};
          var time = moment().format("dddd, MMMM Do YYYY, h:mm:ss a");
          resObj.message = "Welcome Admin: " + id + "Your role is  " + result.rows[0].role;
          resObj.status = 'success';
          res.json(resObj);
        }
        else{
          var resObj = {};
          var time = moment().format("dddd, MMMM Do YYYY, h:mm:ss a");
          resObj.message = "You are not the admin!";
          resObj.status = 'success';
          res.json(resObj);
        }

      }
      else {
        var resObj = {};
        resObj.status = 'error';
        res.json(resObj);
      }

    }
  });

  //     .then(res10 => {
  //       var pwd = res10.rows[0].id;
  //       console.log("password is->" + pwd);
  //     })
  //     .catch(err => {
  // console.log("Error in the cide is->"+err);
  //     })


  // if (id == 'simbo' && pwd == '1') {
  //   var resObj = {};
  //   resObj.status = 'success';
  //   var time = moment().format("dddd, MMMM Do YYYY, h:mm:ss a");
  //   // resObj.message = 'Welcome Simbu to Tecmax,Hope you have a good day!, Good Noon!';
  //   resObj.message = 'Welcome The time right now is' +time ;
  //   res.json(resObj);
  // }
  // else {
  //   var resObj = {};
  //   resObj.status = 'error';
  //   res.json(resObj);



  // }
}

function getUsers(req, res) {


  var validateUserQ = " select id,pwd from user ";
  console.log("query->" + validateUserQ);
  client.execute(validateUserQ, function (err, result) {
    if (err) {
      var resObj = {};
      resObj.status = 'error';
      res.json(resObj);
      console.log("Eror rin code->" + err);
    }
    else {
      var resObj = {};
      resObj.status = 'success';
      resObj.users = result.rows;
      res.json(resObj);



    }
  });

}

function user(req, res) {

var id=req.body.id;
var role=req.body.role;

console.log("id->"+ id);
console.log("role->"+ role);

var insertQ=" update user set role='"+ role +"' where id='"+ id+"'";

console.log("insertQ->"+insertQ);
  client.execute(insertQ, function (err, result) {
    if (err) {
      var resObj = {};
      resObj.status = 'error';
      res.json(resObj);
      console.log("Eror rin code->" + err);
    }
    else {
      var resObj = {};
      resObj.status = 'success';
      console.log("Successfully updated the database");

      res.json(resObj);



    }
  });
  // var validateUserQ = " select id,pwd from user ";
  // console.log("query->" + validateUserQ);
  // client.execute(validateUserQ, function (err, result) {
  //   if (err) {
  //     var resObj = {};
  //     resObj.status = 'error';
  //     res.json(resObj);
  //     console.log("Eror rin code->" + err);
  //   }
  //   else {
  //     var resObj = {};
  //     resObj.status = 'success';
  //     resObj.users = result.rows;
  //     res.json(resObj);



  //   }
  // });

}
