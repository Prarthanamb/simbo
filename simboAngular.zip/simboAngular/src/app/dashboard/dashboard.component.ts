import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  userReq:any={};
  userRes:any={};
  userURL:string;
  constructor( private http: HttpClient) { }

  displayedColumns: string[] = ['id', 'pwd'];
  dataSource :any;

  ngOnInit() {

      this.userURL = 'http://192.168.0.51:10010/getUsers';
      this.http.post(this.userURL, this.userReq)
        .subscribe(x => {
          this.userRes = x;
          console.log(" this.userRes->" + JSON.stringify(this.userRes));
          if (this.userRes.status == 'success') {
this.dataSource=this.userRes.users;
          }
          else {

          }
        }, () => {
        });





  }

}
