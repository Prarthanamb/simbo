var express = require("express");
var app = express();

app.set('port', process.env.PORT || 7880);

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
  next();
});
// var http = require("http");
// const request = require('request');

var bodyParser = require('body-parser')
app.use(bodyParser.json()); // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
  extended: true
}));


app.post('/validateUser', function (req, res) {
  console.log('Inside Login!');
  var id = req.body.id;
  var pwd = req.body.pwd;
  console.log("id i got->"+ id);
  console.log("pwd i got->"+ pwd);
  if (id == 'simbo' && pwd == '1122') {
    var response = "success";
    res.json(response);
  }
  else {
    var response = "error";
    res.json(response);
  }

});

app.post('/add', function (req, res) {
  console.log('Inside Login!');
  var num1 = req.body.num1;
  var num2 = req.body.num2;
  var response = num1 + num2
  res.json(response);
});


app.post('/sub', function (req, res) {
  console.log('Inside Login!');
  var num1 = req.body.num1;
  var num2 = req.body.num2;
  var response = num1 - num2
  res.json(response);

});

app.get('/validateUser', function (req, res) {
  res.json("Hello Simbo");
});


app.listen(app.get('port'));