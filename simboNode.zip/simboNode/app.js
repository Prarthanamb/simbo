var express = require("express");
var app = express();

app.set('port', process.env.PORT || 7880);
var http = require("http");
const request = require('request');

var bodyParser = require('body-parser')
app.use(bodyParser.json()); // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
  extended: true
}));


app.post('/login', function (req, res) {
  console.log('Inside Login!');
  var id = req.body.id;
  var pwd = req.body.pwd;

  res.json("Hello");
});

app.get('/login', function (req, res) {
  res.json("Hello");
});


app.listen(app.get('port'));