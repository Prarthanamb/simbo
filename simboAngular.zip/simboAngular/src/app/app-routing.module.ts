import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { UserComponent } from './user/user.component';

const appRoutes: Routes = [
  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "logout",
    component: LogoutComponent
  }, {
    path: "dashboard",
    component: DashboardComponent
  }, {
    path: "error",
    component: ErrorComponent
  } ,
   {
    path: "user",
    component: UserComponent
  } ,
  {
    path: "",
    redirectTo: "/login",
    pathMatch: "full"
  }
];


@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
