import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public snackBar: MatSnackBar,
    private http: HttpClient) { }
  id: string;
  pwd: string;
  tempObj: any = {};
  loginReq: any = {};
  loginRes: any = {};
  loginURL: string;
  ngOnInit() {
  }

  openSnackBar() {
    this.snackBar.open("himessage", "Hello", {
      duration: 2000,
    });
  }
  checkLogin() {
    console.log("id i got it->" + this.id);
    console.log("pwd i got it->" + this.pwd);
    this.loginReq.id = this.id;
    this.loginReq.pwd = this.pwd;
    this.loginURL = 'http://192.168.0.51:10010/validateUser';
    console.log("this.loginReq->" + JSON.stringify(this.loginReq));
    console.log("this.loginURL->" + this.loginURL);
    this.http.post(this.loginURL, this.loginReq)
      .subscribe(x => {
        this.loginRes = x;
        // console.log(" this.loginRes->" + JSON.stringify(this.loginRes));
        if (this.loginRes.status == 'success') {
console.log("Login Successful");
this.snackBar.open("Success", this.loginRes.message, {
  duration: 2000,
});
        }
        else {
          this.snackBar.open("Failure", 'Login Un Successful', {
            duration: 2000,
          });
        }
      }, () => {
      });




  }
}
